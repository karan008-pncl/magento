var config = {
    map: {
        '*':{
             Swiper: 'js/swiper.min',
             jqueryUi:'js/jquery-ui',
             jqueryUimin:'js/jquery-ui.min'
        }
    },
    paths: { 
         Swiper: 'js/swiper.min',
         jqueryUi:'js/jquery-ui',
         jqueryUimin:'js/jquery-ui.min'
    },
    shim: { 
         Swiper: ['jquery'],
         jqueryUi:'js/jquery-ui',
         jqueryUimin:'js/jquery-ui.min'
    }
};
