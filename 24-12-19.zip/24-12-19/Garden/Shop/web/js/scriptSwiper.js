require(['jquery','Swiper','jqueryUi','jqueryUimin'], function($,Swiper,jqueryUi,jqueryUimin){
 var swiper = new Swiper('.swiper-container', {
      direction: 'horizontal',
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
  $( function() {
    $( "#tabs" ).tabs();
  } );

});