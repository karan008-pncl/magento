var config = {
   paths: {
       'main': 'js/main', // Path to your custom main.js
       'owlCarousel': 'js/owl.carousel.min' // Path to Owl Carousel JS file
   },
   shim: {
       'owlCarousel': {
           deps: ['jquery'] // Owl Carousel depends on jQuery
       },
       'main': {
           deps: ['jquery', 'owlCarousel'] // Ensure jQuery and Owl Carousel are loaded before main.js
       }
   }
};
