require(['jquery', 'owlCarousel'], function($) {
    "use strict";
    $(document).ready(function(){
        $('.carousel-testimony').owlCarousel({
            items: 1, // Default: show 1 item on small screens
            loop: true, // Enable infinite loop
            margin: 30, // Set margin between items
            autoplay: true, // Auto-slide between items
            autoplayTimeout: 3000, // Slide interval (in milliseconds)
            autoplayHoverPause: true, // Pause on hover
            nav: true, // Show navigation arrows
            navText: ['<span class="ion-ios-arrow-back">', '<span class="ion-ios-arrow-forward">'],
            responsive: {
                0: {
                    items: 1 // Show 1 item on mobile devices (0px and above)
                },
                600: {
                    items: 2 // Show 2 items on tablets (600px and above)
                },
                1000: {
                    items: 3 // Show 3 items on larger screens (1000px and above)
                }
            }
        });
    });
});
