<?php

namespace Dolphin\Blog\Block\AddBlog;

class Blog extends \Magento\Framework\View\Element\Template
{

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        // \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        array $data = []
    ) {
        //$this->customerSession = $customerSession;
        $this->objectmanager = $objectmanager;
        parent::__construct($context, $data);
    }

    /**
     * Get form action URL for POST booking request
     *
     * @return string
     */
    public function getFormAction()
    {
        // companymodule is given in routes.xml
        // controller_name is folder name inside controller folder
        // action is php file name inside above controller_name folder

        return 'blog/index/saveblog';

        // here controller_name is index, action is booking
    }

    public function getCustomerData()
    {
        $customerSession = $this->objectmanager->create('Magento\Customer\Model\SessionFactory')->create();
        //echo "adas";
        //print_r($customerSession->getData());
        return $customerSession;
    }
    public function getCustomerId()
    {
        return $this->getCustomerData()->getCustomerId();
        //print_r($this->getCustomerData()->getCustomerId());
        //exit();
    }
}
