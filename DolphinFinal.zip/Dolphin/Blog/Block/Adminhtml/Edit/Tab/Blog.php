<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Dolphin\Blog\Block\Adminhtml\Edit\Tab;

use Magento\Customer\Controller\RegistryConstants;

/**
 * Adminhtml customer orders grid block
 *
 * @api
 * @since 100.0.2
 */
class Blog extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * Sales reorder
     *
     * @var \Magento\Sales\Helper\Reorder
     */

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var  \Magento\Framework\View\Element\UiComponent\DataProvider\CollectionFactory
     */
    protected $collectionFactory;
    protected $model;
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Framework\View\Element\UiComponent\DataProvider\CollectionFactory $collectionFactory
     * @param \Magento\Framework\Registry $coreRegistry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Framework\View\Element\UiComponent\DataProvider\CollectionFactory $collectionFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Dolphin\Blog\Model\Allblog $model,
        array $data = []
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_collectionFactory = $collectionFactory;
        $this->model = $model;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @inheritdoc
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('customer_orders_grid');
        $this->setDefaultSort('created_at');
        $this->setDefaultDir('desc');
        $this->setUseAjax(true);
    }

    /**
     * Apply various selection filters to prepare the sales order grid collection.
     *
     * @return $this
     */
    protected function _prepareCollection()
    {
        //print_r($this->model->getCollection()->getData());
        //print_r($this->_collectionFactory->getReport('sales_order_grid_data_source')->getData());exit();
        /*
        //print_r($collection->getData());
        return parent::_prepareCollection();*/

        $collection = $this->model->getCollection()->addFieldToSelect(
            'blog_id'
        )->addFieldToSelect(
            'customer_id'
        )->addFieldToSelect(
            'subject'
        )->addFieldToSelect(
            'content'
        )->addFieldToSelect(
            'created_at'
        )->addFieldToSelect(
            'updated_at'
        )->addFieldToSelect(
            'status'
        )->addFieldToFilter(
            'customer_id',
            $this->_coreRegistry->registry(RegistryConstants::CURRENT_CUSTOMER_ID)
        );

        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    /**
     * @inheritdoc
     */
    protected function _prepareColumns()
    {
        $this->addColumn('blog_id', ['header' => __('BlogId #'), 'width' => '100', 'index' => 'blog_id']);

        $this->addColumn('subject', ['header' => __('Subject'), 'index' => 'subject']);

        $this->addColumn("status", array(
            "header" => ('Status'),
            'type' => 'options',
            'options' => array(
                '0' => 'Disable',
                '1' => 'Enable',
            ),
            "index" => "status",
        ));
        $this->addColumn(
            'created_at',
            ['header' => __('CreateDate'), 'index' => 'created_at', 'type' => 'datetime']
        );
        $this->addColumn(
            'updated_at',
            ['header' => __('UpdateDate'), 'index' => 'updated_at', 'type' => 'datetime']
        );

        return parent::_prepareColumns();

    }

    /**
     * Retrieve the Url for a specified sales order row.
     *
     * @param \Magento\Sales\Model\Order|\Magento\Framework\DataObject $row
     * @return string
     */
    public function getRowUrl($row)
    {
        return $this->getUrl(
            'blog/allblog/edit',
            ['blog_id' => $row->getId(), 'customer_id' => $this->getRequest()->getParam('id')]
        );
    }

    /**
     * @inheritdoc
     */
    public function getGridUrl()
    {
        return $this->getUrl('blog/allblog/blogtab', ['_current' => true]);
    }
}
