<?php

namespace Dolphin\Blog\Block;

class Edit extends \Magento\Framework\View\Element\Template
{
    protected $_storeManager;
    protected $_urlInterface;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlInterface,
        array $data = []
    ) {
        $this->_storeManager = $storeManager;
        $this->_urlInterface = $urlInterface;
        parent::__construct($context, $data);
    }

    public function getBaseUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }

    public function getLinkUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_DIRECT_LINK);
    }

    public function getMediaUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }

    public function getStaticUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_STATIC);
    }

    public function getCurrentUrl()
    {
        return $this->_storeManager->getStore()->getCurrentUrl(false);
    }

    public function getBaseMediaDir()
    {
        return $this->_storeManager->getStore()->getBaseMediaDir();
    }

    public function getBaseStaticDir()
    {
        return $this->_storeManager->getStore()->getBaseStaticDir();
    }
    public function getUrl($route = '', $params = [])
    {
        return $this->getUrl($route, $params);
    }

    /*   public function customUrl()
{
return $this->getUrl("ss/ddj/kk");
}*/

}
