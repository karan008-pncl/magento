<?php
namespace Dolphin\Blog\Block;

use Magento\Framework\View\Element\Template;

class Fullview extends Template
{

    protected $model;
    public function __construct(
        Template\Context $context,
        \Dolphin\Blog\Model\Allblog $model,
        array $data = []
    ) {

        parent::__construct($context, $data);
        $this->model = $model;
        //$this->_isScopePrivate = true;
    }

    public function getPosts()
    {
        $id = $this->getRequest()->getParam('blog_id');
        $collection = $this->model->load($id);
        return $collection;
    }
}
