<?php
namespace Dolphin\Blog\Block;

class Grid extends \Magento\Framework\View\Element\Template
{
    protected $model;
    protected $objectmanager;
    protected $_postCollectionFactory = null;

    protected $_session;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\UrlInterface $urlInterface,
        \Dolphin\Blog\Model\Allblog $model,
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        array $data = []
    ) {

        $this->model = $model;
        $this->objectmanager = $objectmanager;
        parent::__construct($context, $data);

    }
    public function getCustomerData()
    {
        $customerSession = $this->objectmanager->create('Magento\Customer\Model\SessionFactory')->create();
        return $customerSession;
    }

    public function getCollection()
    {
        $customerId = $this->getCustomerData()->getCustomerId();
        $collection = $this->model->getCollection()
            ->addFieldToFilter('customer_id', $customerId);
        $this->setCollection($collection);

        $page = ($this->getRequest()->getParam('p')) ? $this->getRequest()->getParam('p') : 1;
        //get values of current limit
        $pageSize = ($this->getRequest()->getParam('limit')) ? $this->getRequest()->getParam('limit') : 5;
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);

        return $collection;
    }

    public function getstatuscheck($status)
    {

        if ($status == 1) {
            $statuset = " Enable";
        } else {
            $statuset = "Disable";
        }
        return $statuset;
    }

    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if ($this->getCollection()) {
            // create pager block for collection
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager'
            )->setAvailableLimit(array(5 => 5, 10 => 10, 15 => 15))->setShowPerPage(true)->setCollection(
                $this->getCollection() // assign collection to pager
            );
            $this->setChild('pager', $pager); // set pager block in layout
        }
        return $this;
    }

    // method for get pager html
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

    /* public function customUrl($blogId)
{
return $this->getUrl('blog/index/myblog/');
}*/
}
