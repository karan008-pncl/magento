<?php

namespace Dolphin\Blog\Block;

class Link2 extends \Magento\Framework\View\Element\Html\Link
{
    protected $model;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Dolphin\Blog\Model\Allblog $model,
        \Magento\Customer\Model\Customer $customers

    ) {

        $this->model = $model;
        $this->_customers = $customers;
        parent::__construct($context);
    }
    protected function _toHtml()
    {
        if (false != $this->getTemplate()) {
            return parent::_toHtml();
        }
        $label = $this->escapeHtml($this->getLabel());
        return '<div class="addlist"><a ' . $this->getLinkAttributes() . '  class="action tocart primary">' . $label . '</a></div>';

    }

    public function getCollection()
    {

        $collection = $this->model->getCollection();
        $page = ($this->getRequest()->getParam('p')) ? $this->getRequest()->getParam('p') : 1;
        //get values of current limit
        $pageSize = ($this->getRequest()->getParam('limit')) ? $this->getRequest()->getParam('limit') : 10;
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);

        return $collection;

    }

    public function getCustomername($customerid)
    {
        $customername = $this->_customers->load($customerid);
        $name = $customername->getFirstname() . " " . $customername->getLastname();
        return $name;

    }

    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if ($this->getCollection()) {
            // create pager block for collection
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager'
            )->setCollection($this->getCollection()); // assign collection to pager
            $this->setChild('pager', $pager); // set pager block in layout
        }
        return $this;
    }

    // method for get pager html
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

}
