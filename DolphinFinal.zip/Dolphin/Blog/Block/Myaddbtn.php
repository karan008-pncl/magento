<?php

namespace Dolphin\Blog\Block;

class Myaddbtn extends \Magento\Framework\View\Element\Html\Link
{
    /**
     * Render block HTML.
     *
     * @return string
     */
    protected function _toHtml()
    {
        if (false != $this->getTemplate()) {
            return parent::_toHtml();
        }
        $label = $this->escapeHtml($this->getLabel());
        return '<div class="myaddbtn"><a ' . $this->getLinkAttributes() . '  class="action tocart primary">' . $label . '</a></div>';

    }
}
