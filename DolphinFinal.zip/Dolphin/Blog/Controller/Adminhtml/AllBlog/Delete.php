<?php
namespace Dolphin\Blog\Controller\Adminhtml\AllBlog;

class Delete extends \Magento\Backend\App\Action
{
    protected $resultPageFactory;
    protected $model;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Dolphin\Blog\Model\Allblog $model
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->model = $model;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('blog_id');
        $blog = $this->model->load($id);

        if (!$blog) {
            $this->messageManager->addError(__('Unable to process. please, try again.'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/');
        }

        try {
            $blog->delete();
            $this->messageManager->addSuccess(__('Your blog has been deleted !'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__('Error while trying to delete blog'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/index');
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/index');
    }
}
