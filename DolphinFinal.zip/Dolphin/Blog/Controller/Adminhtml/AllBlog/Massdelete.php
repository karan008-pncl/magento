<?php
namespace Dolphin\Blog\Controller\Adminhtml\AllBlog;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;

class Massdelete extends \Magento\Backend\App\Action
{

    protected $_filter;
    public function __construct(
        Context $context,
        Filter $filter
    ) {
        $this->_filter = $filter;
        parent::__construct($context);
    }

    public function execute()
    {
        $collection = $this->_filter->getCollection($this->_objectManager->create('Dolphin\Blog\Model\ResourceModel\Allblog\Collection'));
        // print_r($collection->getData());exit();
        $recordDeleted = 0;
        foreach ($collection->getItems() as $record) {
            print_r($record->getData());
            //  echo 'id:'.$record->getPostId();
            $record->setBlogId($record->getBlogId());
            $record->delete();
            $recordDeleted++;
        }

        $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $recordDeleted));

        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/index');

    }

}
