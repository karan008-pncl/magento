<?php

namespace Dolphin\Blog\Controller\Adminhtml\Allblog;

class Save extends \Magento\Backend\App\Action
{
    public $model;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Dolphin\Blog\Model\Allblog $model
    ) {
        parent::__construct($context);
        $this->model = $model;

    }

    public function execute()
    {
        // echo '<pre>';
        $blog = $this->getRequest()->getPostValue();
        //print_r($blog);
        //exit();
        if (!empty($blog)) {

            try {

                $model = $this->model;
                // $model->load($id);

                $model->setData($blog);
                $model->save();
                $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
                $this->_redirect('blog/allblog/index');
            } catch (\Exception $e) {
                $this->messageManager->addError(__($e->getMessage()));
                $this->_redirect('blog/allblog/index');
            }
        } else {
            $this->messageManager->addError(__('Row data has been not saved.'));
            $this->_redirect('blog/allblog/index');
        }

    }
}
