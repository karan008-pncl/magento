<?php
namespace Dolphin\Blog\Controller\Index;

class Deleteblog extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
    protected $model;
    protected $redirect;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\App\Response\RedirectInterface $redirect,
        \Magento\Customer\Model\Session $customerSession,
        \Dolphin\Blog\Model\Allblog $model
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->model = $model;
        $this->redirect = $redirect;
        $this->session = $customerSession;
        parent::__construct($context);
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('blog_id');
        /* echo $id;
        exit();*/
        $blog = $this->model->load($id);

        $resultRedirect = $this->resultRedirectFactory->create();
        $redirectUrl = $this->redirect->getRedirectUrl();

        if ($id) {
            $blog = $this->model->load($id);
            $cust_id = $this->session->getId();
            //print_r($cust_id);exit();
            if ($blog->getCustomerId() != $cust_id) {
                $this->messageManager->addError(__('You are not authorized to delete this blog.'));
                $resultRedirect->setPath('blog/index/allblog');
                return $resultRedirect;
            }
        }
        if (!$blog) {
            $this->messageManager->addError(__('Unable to process. please, try again.'));
            $resultRedirect->setPath($redirectUrl);
            return $resultRedirect;
        }

        try {
            $blog->delete();
            $this->messageManager->addSuccess(__('Your blog has been deleted !'));
            $resultRedirect->setPath($redirectUrl);
            return $resultRedirect;
        } catch (\Exception $e) {
            $this->messageManager->addError(__('Error while trying to delete blog'));
            $resultRedirect->setPath($redirectUrl);
            return $resultRedirect;
        }

        $resultRedirect->setPath($redirectUrl);
        return $resultRedirect;
    }
}
