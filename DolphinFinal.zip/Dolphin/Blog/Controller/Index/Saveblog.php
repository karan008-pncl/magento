<?php

namespace Dolphin\Blog\Controller\Index;

class Saveblog extends \Magento\Framework\App\Action\Action
{

    public $model;
    public $blog;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Dolphin\Blog\Model\Allblog $model,
        \Dolphin\Blog\Block\AddBlog\Blog $blog
    ) {
        parent::__construct($context);
        $this->model = $model;
        $this->blog = $blog;
    }
    /**
     * Booking action
     *
     * @return void
     */
    public function execute()
    {
        $custome_id = $this->blog->getCustomerId();
        $blog = $this->getRequest()->getPostValue();
        // $id = $this->getRequest()->getParam('blog_id');

        if (!empty($blog)) {

            try {

                $model = $this->model;
                // $model->load($id);

                $model->setData($blog);
                $model->setCustomerId($custome_id);
                //print_r($model->getData());exit();
                $model->save();
                $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
                $this->_redirect('blog/index/myblog');
            } catch (\Exception $e) {
                $this->messageManager->addError(__($e->getMessage()));
                $this->_redirect('blog/index/myblog');
            }
        } else {
            $this->messageManager->addError(__('Row data has been not saved.'));
            $this->_redirect('blog/index/myblog');
        }

    }
}
