<?php

namespace Dolphin\Blog\Controller\Index;

class Updateblog extends \Magento\Framework\App\Action\Action
{

    public $model;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Dolphin\Blog\Model\Allblog $model
    ) {
        parent::__construct($context);
        $this->model = $model;
    }
    /**
     * Booking action
     *
     * @return void
     */
    public function execute()
    {

        $blog = $this->getRequest()->getPostValue();
        $id = $this->getRequest()->getParam('blog_id');

        if (!empty($blog)) {

            try {

                $model = $this->model;
                $model->load($id);

                $model->setData($blog);

                $model->save();
                $this->messageManager->addSuccess(__('Row data has been successfully updated.'));
                $this->_redirect('blog/index/myblog');
            } catch (\Exception $e) {
                $this->messageManager->addError(__($e->getMessage()));
                $this->_redirect('blog/index/myblog');
            }
        } else {
            $this->messageManager->addError(__('Row data has been not  updated.'));
            $this->_redirect('blog/index/myblog');
        }

    }
}
