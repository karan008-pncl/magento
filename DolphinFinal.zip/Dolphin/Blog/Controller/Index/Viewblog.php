<?php
namespace Dolphin\Blog\Controller\Index;

class Viewblog extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;
    protected $model;
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Dolphin\Blog\Model\Allblog $model,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory) {
        $this->resultPageFactory = $resultPageFactory;
        $this->session = $customerSession;
        $this->model = $model;
        return parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $blog_id = $this->getRequest()->getParam('blog_id');

        if ($blog_id) {
            $blog = $this->model->load($blog_id);
            $cust_id = $this->session->getId();
            //print_r($cust_id);exit();
            if ($blog->getCustomerId() != $cust_id) {
                $this->messageManager->addError(__('You are not authorized to view this blog.'));
                $resultRedirect->setPath('blog/index/allblog');
                return $resultRedirect;
            }
        } else {
            $resultRedirect->setPath('blog/index/allblog');
            return $resultRedirect;
        }

        //print_r($blog_id);exit();
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend((__('View Blog')));

        return $resultPage;
    }
}
