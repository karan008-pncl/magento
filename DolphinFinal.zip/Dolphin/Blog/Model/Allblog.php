<?php
namespace Dolphin\Blog\Model;

class Allblog extends \Magento\Framework\Model\AbstractModel
{
    const CACHE_TAG = 'dolphin_blog';

    protected function _construct()
    {
        $this->_init('Dolphin\Blog\Model\ResourceModel\Allblog');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}
