<?php
/**
 * Webkul_Grid Status Options Model.
 * @category    Webkul
 * @author      Webkul Software Private Limited
 */
namespace Dolphin\Blog\Model;

use Magento\Framework\Data\OptionSourceInterface;

class Customerid implements OptionSourceInterface
{
    protected $model;
    protected $_customerFactory;

    public function __construct(
        \Dolphin\Blog\Model\Allblog $model,
        \Magento\Customer\Model\CustomerFactory $_customerFactory
    ) {
        $this->model = $model;
        $this->_customerFactory = $_customerFactory;
    }

    public function toOptionArray()
    {
        $collection = $this->_customerFactory->create()->getCollection();
        //echo '<pre>';
        //print_r($collection->getData());exit();
        $options = [];
        foreach ($collection as $value) {

            $options[] = ['label' => $value->getName(), 'value' => $value->getId()];

        }
        return $options;
    }
}
