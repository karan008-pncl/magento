<?php
namespace Dolphin\Blog\Model\ResourceModel;

class Allblog extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('dolphin_blog', 'blog_id');
    }
}
