<?php
namespace Dolphin\Blog\Model\ResourceModel\Allblog;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'blog_id';

    protected function _construct()
    {
        $this->_init('Dolphin\Blog\Model\Allblog', 'Dolphin\Blog\Model\ResourceModel\Allblog');
    }
}
