<?php

namespace Dolphin\Blog\Observer;

use Magento\Framework\Event\ObserverInterface;

class CustomerLogin implements ObserverInterface
{

    protected $messageManager;

    public function __construct(
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        $this->messageManager = $messageManager;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        // echo "Customer LoggedIn <br>";

        $customer = $observer->getEvent()->getCustomer();
        //$customername = $customer->getName(); //Get customer name
        //echo " ".$customer;exit();
        $first_name = $customer->getFirstname();
        $last_name = $customer->getLastname();

        if ($customer) {
            $this->messageManager->addSuccess(__("Welcome Customer " . $first_name . " " . $last_name));
        }

        return $observer;
    }
}
