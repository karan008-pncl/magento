<?php

namespace Dolphin\Blog\Ui\Component\Listing\Allblog\Column;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;

class Action extends \Magento\Ui\Component\Listing\Columns\Column
{
    /** Url path */
    const ROW_EDIT_URL = 'blog/allblog/edit';
    const ROW_DELETE_URL = 'blog/allblog/delete';
    /** @var UrlInterface */
    protected $_urlBuilder;

    /**
     * @var string
     */
    private $_editUrl;
    private $_deleteUrl;

    /**
     * @param ContextInterface   $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface       $urlBuilder
     * @param array              $components
     * @param array              $data
     * @param string             $editUrl
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = [],
        $editUrl = self::ROW_EDIT_URL,
        $deleteUrl = self::ROW_DELETE_URL
    ) {
        $this->_urlBuilder = $urlBuilder;
        $this->_editUrl = $editUrl;
        $this->_deleteUrl = $deleteUrl;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source.
     *
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $name = $this->getData('name');
                if (isset($item['blog_id'])) {
                    $item[$name] = [
                        'edit' => [
                            'href' => $this->_urlBuilder->getUrl(
                                $this->_editUrl,
                                [
                                    'blog_id' => $item['blog_id'],
                                ]
                            ),
                            'label' => __('Edit'),
                        ],
                        'delete' => [
                            'href' => $this->_urlBuilder->getUrl(
                                $this->_deleteUrl,
                                [
                                    'blog_id' => $item['blog_id'],
                                ]
                            ),
                            'label' => __('Delete'),
                        ],
                        // 'href' => $this->_urlBuilder->getUrl(
                        //     $this->_editUrl,
                        //     ['post_id' => $item['post_id']]
                        // ),
                        // 'label' => __('Edit'),
                    ];
                }
            }
        }

        return $dataSource;
    }

}
