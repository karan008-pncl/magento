<?php

namespace Dolphin\Blog\Ui\Component\Listing\Allblog\Column;

use \Magento\Framework\Api\SearchCriteriaBuilder;
use \Magento\Framework\View\Element\UiComponentFactory;
use \Magento\Framework\View\Element\UiComponent\ContextInterface;
use \Magento\Ui\Component\Listing\Columns\Column;

class Customeremail extends \Magento\Ui\Component\Listing\Columns\Column
{
    protected $_searchCriteria;
    protected $_customerModel;
    protected $_customerFactory;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        SearchCriteriaBuilder $criteria,
        \Magento\Customer\Model\CustomerFactory $_customerFactory,
        array $components = [],
        array $data = []
    ) {
        $this->_searchCriteria = $criteria;
        $this->_customerFactory = $_customerFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $id = $item["customer_id"];

                $collection = $this->_customerFactory->create()->load($id);
                // print_r($collection->getData());exit();
                $name = $item[$this->getData('name')] = $collection->getEmail();
                $html = __($name);

                $item[$this->getData('name')] = $html;
            }
        }
        return $dataSource;
    }
}
