var config = {
    map: {
        '*': {
            editor: 'Dolphin_Blog/js/editor',
        }
    }
};