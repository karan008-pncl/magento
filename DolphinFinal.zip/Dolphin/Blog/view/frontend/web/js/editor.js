require(["jquery", "domReady!"], function($){
    $(document).on('click', '#blog_submit', function(){
        alert('jquery loaded with success!');
    });
});