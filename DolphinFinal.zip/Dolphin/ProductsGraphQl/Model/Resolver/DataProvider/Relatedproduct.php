<?php


namespace Dolphin\ProductsGraphQl\Model\Resolver\DataProvider;

/**
 * Class Relatedproduct
 *
 * @package Dolphin\ProductsGraphQl\Model\Resolver\DataProvider
 */
class Relatedproduct extends \Magento\Framework\View\Element\Template
{
	protected $_productRepository;
    public function __construct(
    \Magento\Backend\Block\Template\Context $context,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        array $data = []
    )
    {
       $this->_productRepository = $productRepository;
        parent::__construct($context, $data);  
    }
    /**
     * @params string $sku
     * this function return all the product data by product sku
     **/
    public function getProductBySku($sku)
    {
        return $this->_productRepository->get($sku);
    }

    public function getRelatedproduct($sku)
    {
        
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/rvgraph.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        
        $_product = $this->getProductBySku($sku);
        $attributes = $_product->getAttributes();// All Product Attributes
        $attributes_data = [];
        $x=0;

        foreach ($attributes as $attribute) {
            //ttributes_data['sku'] = "Ravi Ojha";
            //if($attribute->getIsUserDefined()){ // Removed the system product attribute by checking the current attribute is user created
             //$logger->info(var_dump($attribute->getFrontend()->getLabel()));
               $attributeLabel = $attribute->getFrontend()->getLabel();
                $attributeValue = $attribute->getFrontend()->getValue($_product);
                if($attribute->getAttributeCode()=="test_attr"){
                    //$logger->info($attributeValue);
                    $attributeLabelAndValue = $attributeLabel." - ".$attributeValue;
                    $attributes_data['sku'] = $attributeLabelAndValue;
               }
           // }
                $attributes_data['related_id'] ='1111111111111';
                $attributes_data['customoption'] ='rrrrrrrrrrrrrrrr';
            $x++;
        }
        echo "<prE>";
        print_r($attributes_data);die;
        
        return $attributes_data;
    }
}

