<?php


namespace Dolphin\ProductsGraphQl\Model\Resolver;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

/**
 * Class Relatedproduct
 *
 * @package Dolphin\ProductsGraphQl\Model\Resolver
 */
class Relatedproduct implements ResolverInterface
{

    private $relatedproductDataProvider;

    /**
     * @param DataProvider\Relatedproduct $relatedproductRepository
     */
    public function __construct(
        DataProvider\Relatedproduct $relatedproductDataProvider
    ) {
        $this->relatedproductDataProvider = $relatedproductDataProvider;
    }

    /**
     * @inheritdoc
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
         $sku = $this->getSku($args);
         //echo $sku;die;
        $relatedproductData = $this->relatedproductDataProvider->getRelatedproduct($sku);
        return $relatedproductData;
    }

     private function getSku(array $args)
    {
        if (!isset($args['sku'])) {
            throw new GraphQlInputException(__('"SKU should be specified'));
        }
        return $args['sku'];
    }
}

